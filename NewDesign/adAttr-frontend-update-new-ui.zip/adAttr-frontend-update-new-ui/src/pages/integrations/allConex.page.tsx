import { styled } from "styled-components";
import { useQuery } from "@tanstack/react-query";
import dayjs from "dayjs";

import { getAPIKeysQuery } from "~/services/integrations";
import Breadcrumb from "~/components/Breadcrumb";

import ApiKeyGenerator from "./SDK_apikey.page";

export const Component = () => {
  const breadcrumbItems = [
    { url: "dashboard", label: "Overview", active: false },
    { url: "integrations", label: "Integrations", active: true },
  ];
  const { data: keys } = useQuery(getAPIKeysQuery());

  const key = (keys ?? [])[0];

  return (
    <MainContainer>
      <Breadcrumb items={breadcrumbItems} />

      <Header>
        <IntegrationHeader>All Integrations</IntegrationHeader>
      </Header>

      <IntegrationDetails>
        <ApiKeyGenerator />
      </IntegrationDetails>

      {key && <Container>Last Key Generated: {dayjs(key.created_at).format("MM/DD/YYYY hh:mm:ss A")}</Container>}
    </MainContainer>
  );
};

const MainContainer = styled.div`
  display: flex;
  flex-direction: column;
  background-color: rgba(248, 236, 224, 0.5);
  border-radius: 12px;
  padding: 16px 20px;
  height: 100vh;
`;

const Header = styled.div`
  display: flex;
  justify-content: space-between;
  padding: 8px 16px;
  background-color: #fff;
  border-radius: 12px;
`;

const IntegrationHeader = styled.h2`
  font-family: Montserrat, sans-serif;
  font-size: 20px;
  font-weight: 700;
  color: #6a6055;
  padding: 6px;
`;

const IntegrationDetails = styled.section`
  margin-top: 16px;
`;

const Container = styled.div`
  display: flex;
  flex-direction: column;
  margin-top: 4px;
  padding: 8px 16px;
  background-color: #fff;
  border-radius: 12px;
  tr {
    height: 45px;
    padding: 8px 16px;
  }
`;
