import { useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { toast } from "react-toastify";

import { IUser } from "../store/types";
import useStore from "../store";

export const Component = () => {
  const navigate = useNavigate();
  const store = useStore();
  const [searchParams] = useSearchParams();

  const fetchUser = async () => {
    try {
      store.setRequestLoading(true);

      const valorParametro = JSON.parse(searchParams.get("data") as string);
      const user = valorParametro as IUser;
      console.log("user:", user);
      store.setRequestLoading(false);
      store.setAuthUser(user);
      // eslint-disable-next-line
    } catch (error: any) {
      store.setRequestLoading(false);
      if (error.error) {
        error.error.forEach((err: { message: string }) => {
          toast.error(err.message, {
            position: "top-right",
          });
        });
        return;
      }
      const resMessage =
        (error.response && error.response.data && error.response.data.message) || error.message || error.toString();
      console.log("error: ", error);
      if (error?.message === "You are not logged in") {
        navigate("/login");
      }

      toast.error(resMessage, {
        position: "top-right",
      });
    }
  };

  useEffect(() => {
    fetchUser();
  }, []);

  const user = store.authUser;

  return (
    <section className="bg-ct-blue-600  min-h-screen pt-20">
      <div className="max-w-4xl mx-auto bg-ct-dark-100 rounded-md h-[20rem] flex justify-center items-center">
        <div>
          <p className="text-5xl text-center font-semibold">Profile Page</p>
          {!user ? (
            <p>Loading...</p>
          ) : (
            <div className="flex items-center gap-8">
              <div>
                <img src={user.picture} className="max-h-36" alt={`profile photo of ${user.given_name}`} />
              </div>
              <div className="mt-8">
                <p className="mb-3">ID: {user.sub}</p>
                <p className="mb-3">Name: {user.given_name}</p>
                <p className="mb-3">Email: {user.email}</p>
                <p className="mb-3">Role: {user.role}</p>
                <p className="mb-3">Provider: {user.provider}</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};
