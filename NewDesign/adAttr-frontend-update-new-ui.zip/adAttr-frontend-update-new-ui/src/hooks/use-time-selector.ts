import { useMemo, useState } from "react";
import dayjs from "dayjs";

export const DURATION_OPTIONS = ["1W", "1M", "1Y", "MAX"] as const;
export const GROUP_BY_OPTIONS = {
  "1W": ["day"],
  "1M": ["day"],
  "1Y": ["day", "month"],
  MAX: ["day", "month", "year"],
} as const;

const useTimeSelector = () => {
  const [duration, _setDuration] = useState<string>(DURATION_OPTIONS[0]);
  const [groupBy, setGroupBy] = useState<string>(GROUP_BY_OPTIONS[duration as (typeof DURATION_OPTIONS)[number]][0]);

  const groupByOptions = useMemo(
    () => GROUP_BY_OPTIONS[duration as (typeof DURATION_OPTIONS)[number]] as readonly string[],
    [duration],
  );
  const [startTime, endTime] = useMemo(() => {
    switch (duration) {
      case "1W":
        return [dayjs().add(-1, "week").startOf("day"), dayjs().endOf("day")];
      case "1M":
        return [dayjs().add(-1, "month").startOf("day"), dayjs().endOf("day")];
      case "1Y":
        return [dayjs().add(-1, "year").startOf("day"), dayjs().endOf("day")];
      default:
        return [undefined, undefined];
    }
  }, [duration]);

  const setDuration = (value: string) => {
    const options = GROUP_BY_OPTIONS[value as (typeof DURATION_OPTIONS)[number]];
    _setDuration(value);
    if (!(options as readonly string[]).includes(groupBy)) {
      setGroupBy(options[0]);
    }
  };

  return {
    duration,
    setDuration,
    groupByOptions,
    groupBy,
    setGroupBy,
    startTime,
    endTime,
  };
};

export default useTimeSelector;
