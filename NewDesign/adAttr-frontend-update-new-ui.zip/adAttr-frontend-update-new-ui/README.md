# Ad Attribution System Frontend

### Description

Frontend for Ad Attribution system

### Project Setup

1. Install Node.js
2. Install dependencies using `yarn install`
3. Run project using `yarn dev`

### Coding Standards

#### File Structure

- Separate components, styles, and utility functions into their respective directories.
- Follow a consistent naming convention for files and directories.

#### Naming Conventions

- Use descriptive names for variables, functions, and components.
- Follow camelCase for variable and function names.
- Use PascalCase for component names.

#### Formatting

- Use Prettier to format the code

#### Linting

- Use ESLint for linting
